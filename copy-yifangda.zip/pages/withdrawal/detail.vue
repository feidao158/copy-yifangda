<template>
	<view class="table"></view>
</template>

<script>
</script>

<style>
</style>
